package com.mani.kiranaapp.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mani.kiranaapp.Database.DBHelper;
import com.mani.kiranaapp.R;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
TextView tvlogin,tvnewuser,tvfb,tvgoogle;
    EditText etphone,etpass;

    DBHelper db=null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DBHelper(this);
        tvlogin= (TextView) findViewById(R.id.tvlogin);
        tvnewuser=(TextView) findViewById(R.id.newuser);
        tvfb=(TextView) findViewById(R.id.tvfb);
        tvgoogle=(TextView) findViewById(R.id.tvgoogle);
        etphone= (EditText) findViewById(R.id.etphone);
        etpass= (EditText) findViewById(R.id.etpass);
        tvnewuser.setOnClickListener(this);
        tvgoogle.setOnClickListener(this);
        tvfb.setOnClickListener(this);
        tvlogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String phone=etphone.getText().toString();
        String pass=etpass.getText().toString();
        switch(v.getId()){
            case R.id.newuser:
                Intent i=new Intent(this,NewUserActivity.class);
                startActivity(i);
                break;
            case R.id.tvlogin:
                boolean val=db.login(phone,pass);
                if(val){
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Login Fail", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tvgoogle:

                break;
            case R.id.tvfb:
                break;
        }

    }
}
