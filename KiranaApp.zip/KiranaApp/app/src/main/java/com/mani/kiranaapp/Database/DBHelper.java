package com.mani.kiranaapp.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sakshi.banger on 14-03-2017.
 */
public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;

    public DBHelper(Context context) {
        super(context, "SakshiSB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Register (phone Text Primary Key,password Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public long insertnewUser(String phone, String pass) {
        db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("phone", phone);
        cv.put("password", pass);
        long id = db.insert("Register", null, cv);
        return id;
    }

    public boolean login(String phone, String pass) {
        boolean val;
        db = this.getReadableDatabase();
        Cursor mcursor = db.rawQuery("Select * from " + "Register" + "where phone=? AND password=?", new String[]{phone, pass});
        if (mcursor != null && mcursor.getCount() > 0) {
            return true;


        }
        else{
            return false;
        }
    }
}
