package com.mani.kiranaapp.Activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mani.kiranaapp.Database.DBHelper;
import com.mani.kiranaapp.R;

/**
 * Created by sakshi.banger on 14-03-2017.
 */
public class NewUserActivity extends Activity implements View.OnClickListener {
    TextView tvregister,tvcancel;
    EditText etphone,etpass,etconfirmpass;
    DBHelper db=null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_main);
        tvregister= (TextView) findViewById(R.id.register);
        tvcancel= (TextView) findViewById(R.id.tvcancel);
        db=new DBHelper(this);
        etphone= (EditText) findViewById(R.id.etphone);
        etpass= (EditText) findViewById(R.id.etpass);
        etconfirmpass= (EditText) findViewById(R.id.etconfirmpass);
        tvregister.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String phone=etphone.getText().toString();
        String pass=etpass.getText().toString();
        String confirmpass=etconfirmpass.getText().toString();
        if(phone.equals("")){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("oops!");
            alertDialog.setMessage("phone field is empty");
            alertDialog.setButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //dismiss the dialog
                        }
                    });
            alertDialog.show();
        }
        else if(pass.equals("")){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("oops!");
            alertDialog.setMessage("pass field is empty");
            alertDialog.setButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //dismiss the dialog
                        }
                    });
            alertDialog.show();
        }
        else if(confirmpass.equals("") || !confirmpass.equals(pass)){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("oops!");
            alertDialog.setMessage("confirmpass field is empty or pass and confirmpass not same?");
            alertDialog.setButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //dismiss the dialog
                        }
                    });
            alertDialog.show();
        }
        switch(v.getId()){
            case R.id.register:
                long id=db.insertnewUser(phone,pass);
                if(id!=-1){
                    Intent i=new Intent(this,MainActivity.class);
                    startActivity(i);
                }
                else{
                    Toast.makeText(NewUserActivity.this, "Already Phone number registered", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tvcancel:
                etphone.getText().clear();
                etpass.getText().clear();
                etconfirmpass.getText().clear();
                break;
        }
    }
}
